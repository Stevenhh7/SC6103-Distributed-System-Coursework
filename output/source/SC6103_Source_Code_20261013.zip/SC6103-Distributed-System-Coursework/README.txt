SC6103 Distributed Flight Information System

Requirements: JDK 17+ (including javac) and Python 3.10+.
The application and tests require only standard libraries.
Run commands from the extracted project directory.

Build on macOS/Linux:
  sh server/build.sh
Build on Windows PowerShell:
  .\server\build.ps1

Server:
  java -cp server/build/classes flight.ServerMain --bind 0.0.0.0 --port 6789 --semantics amo
Client on another computer:
  python -X utf8 -m client --server <server-IPv4> --port 6789 --semantics amo
Use python3 instead of python on macOS/Linux if needed.
Use the same semantics on both sides; replace amo with alo to compare modes.
Restart the server to reset the in-memory flights, subscriptions and history.

Run the retained automated checks and local UDP matrix:
  python -m experiments.verify_all --matrix
Recheck the retained LAN logs:
  python tools/audit_lan_evidence.py

Contents: application sources, build scripts, test sources, experiment tools,
original screenshots and test evidence. PACKAGE_MANIFEST.json records file hashes.
Markdown documents, the lab report, compiled classes, caches and nested archives
are intentionally excluded. Submit the lab report separately.

# 三台电脑演示步骤

整理：B，2026-10-07。2026-10-10 更新：真实本机 Java 17 UDP 已验收；本三机脚本仍待实际执行。

## 环境与人员

| 电脑 | 角色 | 操作者 | 准备 |
|---|---|---|---|
| S | Java 服务端 | Zhang Zhiyin | Java17+、编译产物、服务端日志、实际局域网 IPv4 |
| M | Python 监控/查询客户端 | Peng Jinyu | Python3.10+、仓库、独立 session |
| R | Python 订座/第二监控客户端 | Ji Chengyu | Python3.10+、仓库、独立 session |

三台电脑连接可互通的局域网。S 确认允许 Python/Java 所需的 UDP6789 入站规则；按学校网络实际条件设置规则，不全局关闭防火墙。用 S 的真实 IPv4，下面示例 `192.168.1.10` 必须替换。

## 第一段：六业务与单监控

S：

```powershell
.\server\build.ps1
java -cp server/build/classes flight.ServerMain --bind 0.0.0.0 --port 6789 --semantics amo
```

M/R 各开一个菜单，默认生成不同 UUID：

```powershell
python -m client --server 192.168.1.10 --port 6789 --semantics amo --verbose --log-file evidence/b/demo/client-M.jsonl
```

R 的日志文件改为 client-R.jsonl。先演示英文路线返回1001/1002、中文路线返回1004/1005、1001详情；1003订座失败且无副作用。每项说明相应网络 op 和状态。

M：选择4，航班1001，监控20秒，等待“Monitor confirmed”。R：选择3，1001，订座1。M 应显示“Seat update: flight 1001, available seats 9, sequence 1”；期间阻塞菜单，到期显示“Monitoring ended for flight 1001.”后返回。R：设置票价120，再加价20，查询实际总价140；票价操作不会触发座位事件。

## 第二段：两个监控者与隔离

为便于解释初态，S 正常结束服务端并重新启动。M 和 R 都监控1001，等待两者确认。

因为现有客户端在监控期间阻塞菜单，双监控时需在 R 电脑另开一个辅助 Python 进程订座；它拥有新 session。仍是三台电脑，不要求 C 改成并发菜单。辅助进程只用正常菜单订座1并退出。

M/R 两个监控者应各收到1001余座9、seq1。再复位，M监控1001、R监控1002；辅助进程订座1001，只有M收到。无事件监控也要到期结束。

## 第三段：调用语义与丢包

使用 cases.md / run_suite.ps1 的固定1001数据与单客户端实验。分别重启 ALO/AMO 服务端，丢目标首次订座或加价回复，展示客户端 attempts、最终余座/票价、A 的业务执行次数和 cacheHit。SET最终票价一致时必须看服务端执行日志。

展示全请求丢失和全回复丢失时，客户端都报告“未知”，但是查询出的最终状态不同。代理仅做本地受控故障，三机基本通信仍直接连接 S。

## 讲解与证据

- A 解释手工协议、请求键/peer、缓存、发送与丢包顺序。
- B 解释六业务、校验先于修改、不可变快照、订阅替换/过期、事件身份和 remainingMillis。
- C 解释同字节重传、匹配/未知结果、callback过滤与截止时间。

记录真实 IP、运行环境、完整命令、两端日志和截图。当前文档没有填入三机通过结论；演练后由 B 填 results.csv 和报告。

## macOS/Linux 构建与现场记录

仓库根目录执行 `sh server/build.sh`，其余 java 命令相同；python 可换为 python3。不要用会自行启动本机服务端的 run_suite.py 代替三机通信演示。

现场记录以下项目，未实测不要勾选：

- [ ] S/M/R 三台不同电脑的 IPv4、系统、Java/Python 版本与日期。
- [ ] 六操作和中文路线成功、错误路径无副作用。
- [ ] 双监控收到同一次订座事件，另一航班隔离，截止后不再显示。
- [ ] ALO/AMO 首次回复丢失对照，保存同一请求身份的执行/缓存日志。
- [ ] 三端日志和截图保存到 evidence/demo/，填写报告与实际结果表。

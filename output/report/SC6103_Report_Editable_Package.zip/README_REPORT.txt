Report and evidence material package, updated 13 October 2026.
This is NOT the complete application source-code submission archive.
The separate SC6103_Source_Code_20261013.zip contains all application source and automated evidence.
Submit the PDF through the lab report item. Every student must separately submit the compulsory peer evaluation.
Rebuild this report: install reportlab, then run python tools/build_report.py.
Demo: slot 11, 17 October 2026, 14:15-14:30, LT8.

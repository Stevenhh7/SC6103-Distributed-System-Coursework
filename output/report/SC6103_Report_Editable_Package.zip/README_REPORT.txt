SC6103 illustrated report - revised 13 October 2026; experiments 12 October 2026

Final PDF: output/pdf/SC6103_Project_Report.pdf
Editable Markdown: report/项目报告.md (relative images in report/assets/).
All original screenshots and their hashes: evidence/demo/20261012-submitted-screenshots/.
The three retained B logs are included. This package does not contain reconstructed A/C logs.

To rebuild from the extracted root: install ReportLab, then run python tools/build_report.py.
The renderer embeds available Arial/Consolas fonts on Windows or uses available macOS fonts.
Source screenshots remain unchanged; PDF viewports frame selected server records.

This is the report/editable-evidence package, not the application-source submission ZIP.
The application's Java/Python source and full automated evidence remain in the project repository.
